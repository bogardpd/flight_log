$(function() {
  $('#trip_id').change(function() {
    this.form.submit();
  })
});
